package com.mycompany.activitylifecycletest2;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Administrator on 2016/4/27.
 */
public class DialogActivity extends Activity {
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_layout);
    }
}
